function iSound(a)
{
    var r = ((a.charCodeAt(0) - parseInt('0xac00',16)) /28) / 21;
    var t = String.fromCharCode(r + parseInt('0x1100',16));
    return t;
}
//중성
function mSound(a)
{
    var r = ((a.charCodeAt(0)- parseInt('0xac00',16)) / 28) % 21;
    var t = String.fromCharCode(r + parseInt('0x1161',16));
    return t;
}
//종성
function tSound(a)
{
    var r = (a.charCodeAt(0) - parseInt('0xac00',16)) % 28;
    var t = String.fromCharCode(r + parseInt('0x11A8',16) -1);
    return t;
}

function txtbutton_click(){
    let value=document.getElementById("txt").querySelector(".txtfield > input").value;
    let values=value.toString().replace(/\s/gi,"");
    let imgvposition=0;
    let imgrposition=0;
    let imgsize=156;

    for(let i=0; i<values.length; i++){
        let is=iSound(values[i]);
        let ms=mSound(values[i]);
        let ts=tSound(values[i]);
        let vsCode=values[i].charCodeAt(0);
        let isCode=is.charCodeAt(0)+8241;   
        let msCode=ms.charCodeAt(0)+8174;   
        let tsCode=ts.charCodeAt(0)+8073; 
        let times = 0;
        let maxlength = 160;
        if(vsCode<12644){
            times = 1;
            isCode=vsCode;
        }else if(tsCode===12592){
            times = 2;
        }else{
            times = 3;
        }

        for(let j=0; j<times; j++){
            let k = Math.floor(Math.random()*(40-1+1)) +1;
            var q = "#imgfield > .imgmain > .row:nth-child("+(imgrposition+1)+") > .items:nth-child("+(imgvposition+1)+") > .itemschild:nth-child("+(j+1)+")";
            try{
                document.querySelector(q).innerHTML="<img src=\"img/"+k+".png\" width=\""+maxlength+"\" height=\""+maxlength+"\">";
            }catch{
                console.log(q);
            }
        }

        imgvposition++;
        if(imgvposition===4){
            imgvposition=0;
            imgrposition++;
        }
    }
    anime({
        targets:document.getElementById("txt"),
        duration:1000,
        easing:"linear",
        top:"-30%",
        opacity:"0"
    });

    anime({
        targets:document.getElementById("imgfield"),
        duration:1000,
        delay:1000,
        easingl:"linear",
        top:"10%",
        opacity:"1"
    });
    
}

function download(){
    printDiv(document.getElementById('imgfield'));
}

function printDiv(div){
    html2canvas(div).then(function(canvas){
        var myImage=canvas.toDataURL();
        downloadURI(myImage,document.getElementById("text").innerHTML.toString());
    });
}

function downloadURI(uri,name){
    var link=document.createElement("a");
    link.download=name;
    link.href=uri;
    document.body.appendChild(link);
    link.click();
}
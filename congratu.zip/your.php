<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/final.css?v=1">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Noto+Sans+KR:100,300,400,500&display=swap">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Poiret+One&display=swap">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    
    <script type="text/javascript" src="js/anime.js"></script>
    <script type="text/javascript" src="js/html2canvas.js"></script>
    <script type="text/javascript" src="js/final.js?v=1"></script>
    
    <title>Document</title>
</head>
<body>
    <a id="text" hidden></a>
    <div id="imgfield">
        <div class="imgmain">
            <div class="row">
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
            </div>
            <div class="row">
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
            </div>
            <div class="row">
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
            </div>
            <div class="row">
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
            </div>
            <div class="row">
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
                <div class="items">
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                    <div class="itemschild"></div>
                </div>
            </div>
        </div>
        <div class="buttons">
            <div class="button_home button" onclick="window.location.href='final.php';"><i class="material-icons">home</i></div>
            <div class="button_down button" onclick="download();"><i class="material-icons">save_alt</i></div>
        </div>
    </div>
    <div id="checkfield"></div>
    <div id="txt">
        <div class="txthead">글씨를 입력하세요</div>
        <div class="txtfield">
            <input type="text" name="text" maxlength="20" placeholder="20글자 이내로 입력해 주세요.">
        </div>
        <div class="button" onclick="txtbutton_click();">확 인</div>
    </div>
    <div class="bonobono">
        <div class="bonoimg">
        </div>
    </div>

</body>
</html>